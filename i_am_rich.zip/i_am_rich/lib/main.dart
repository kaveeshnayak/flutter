import 'package:flutter/material.dart';

void main() {
  runApp((

      MaterialApp(
          debugShowCheckedModeBanner: false,
          home:Scaffold(
              backgroundColor: Colors.grey,
              appBar: AppBar(

                  centerTitle: true,
                  title:Text('I am Rich')
              ),
              body:Center(
                  child:Image(image:
                  NetworkImage('http://www.pngmart.com/files/1/Diamond-Vector-Clip-Art-PNG.png')
                    ,)
              )
          )
      )

  )
  );
}
